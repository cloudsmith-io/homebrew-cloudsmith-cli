# Maintainers

The project is maintained by the Cloudsmith team.

Any member of the Cloudsmith organization may review and approve contributions.

# Contributors

The following contributors (in alphabetical order) are held in eternal high esteem and gratitude for their glorious contributions to the project:

- Carlos Gonzalez ([@LowzG](https://github.com/LowzG))
- Jamie Brynes ([@jamiebrynes7](https://github.com/jamiebrynes7))
- Pablo Sanchez ([@pablogrs](https://github.com/pablogrs))
- Patrick McClory ([@mcclory](https://github.com/mcclory))

# Thanks

We'd also like to say thank you to the following people (in alphabetical order), for raising issues, providing suggestions or just for being awesome:

- Michal Nowak ([@Mno-hime](https://github.com/Mno-hime))
- Rob Madole ([@robmadole](https://github.com/robmadole))
- Sean Allen ([@SeanTAllen](https://github.com/SeanTAllen))
- Jesse Rhoads ([@JesseRhoads-PD](https://github.com/JesseRhoads-PD))
- Julian Pulgarín ([@jpulgarin](https://github.com/jpulgarin))
- Pierre Gergondet ([@gergondet](https://github.com/gergondet))
